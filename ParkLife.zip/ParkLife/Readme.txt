Our executable has been tested to work on both Linux and Windows, however not tested on Mac systems.

A requirement to run the program, is the installation of java on your system. If you do not possess java, fear not, there is plenty of material online on how to install it.

To run the game either double click ParkLife.jar or rune java -jar ParkLife.jar from a terminal.

If this does not work please open the game project (found in directory garden_2311_working) with an IDE (we used IntelliJ) and build and run it.