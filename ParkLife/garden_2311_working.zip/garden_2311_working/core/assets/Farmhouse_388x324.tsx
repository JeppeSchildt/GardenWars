<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="Farmhouse_388x324" tilewidth="32" tileheight="32" tilecount="120" columns="10">
 <image source="Farmhouse_388x324.png" width="324" height="388"/>
</tileset>
