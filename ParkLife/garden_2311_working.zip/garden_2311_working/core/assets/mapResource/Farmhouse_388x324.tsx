<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="Farmhouse_388x324" tilewidth="324" tileheight="388" tilecount="1" columns="1">
 <image source="Farmhouse_388x324.png" width="324" height="388"/>
</tileset>
