<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="Trees-green" tilewidth="32" tileheight="32" tilecount="1024" columns="32">
 <image source="Trees-green.png" width="1024" height="1024"/>
</tileset>
