<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="fence_remix" tilewidth="32" tileheight="32" tilecount="21" columns="3">
 <image source="fence_remix.png" width="96" height="224"/>
</tileset>
