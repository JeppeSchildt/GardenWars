<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="house1" tilewidth="32" tileheight="32" tilecount="35" columns="5">
 <image source="house1.png" width="163" height="228"/>
</tileset>
