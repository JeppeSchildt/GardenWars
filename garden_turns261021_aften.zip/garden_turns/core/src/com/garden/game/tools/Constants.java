package com.garden.game.tools;

public class Constants {
    public static final Integer GRASS = 1000;
}
